from django.urls import path
from . import views
urlpatterns=[

path('',views.index,name='index'),
path('sqr',views.sqr,name='sqr'),
path('home',views.home,name='home'),
path('sms',views.broadcast_sms,name='broadcast_sms')

]