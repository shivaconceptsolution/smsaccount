from django.shortcuts import render
from django.http import HttpResponse
import requests
from django.conf import settings
from django.core.mail import send_mail
from twilio.rest import Client
def index(request):
	subject = 'welcome to GFG world'
	message = 'Hi thank you for registering in geeksforgeeks.'
	email_from = settings.EMAIL_HOST_USER
	recipient_list = ['shiva.gtm@gmail.com','veerurajput94@gmail.com']
	send_mail( subject, message, email_from, recipient_list )
	return HttpResponse("Mail Sent")
	

def sqr(request):
	num =5
	s = num*num
	c = s*num
	return HttpResponse("Square is "+str(s) + " Cube is "+str(c) + "Result is ="+ str(type(num).__name__))


def home(request):
    return render(request,"guest/hello.html")	


def broadcast_sms(request):
    message_to_broadcast = "om namah shivay"
    client = Client('AC3eaee230bfadba424104403b58a6bfc2','059bbf3b5e47d578f70298fae7a98aae')
   
    client.messages.create(to='+919098581549',
                                   from_='+18633426532',
                                   body=message_to_broadcast)
    return HttpResponse("messages sent!", 200)   